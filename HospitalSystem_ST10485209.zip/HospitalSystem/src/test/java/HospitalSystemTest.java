/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.practicalassignment1.Inpatient;
import com.mycompany.practicalassignment1.HospitalSystem;
import com.mycompany.practicalassignment1.Patient;
import com.mycompany.practicalassignment1.PatientCategory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class HospitalSystemTest {

    private HospitalSystem hospital;

    @BeforeEach
    public void setUp() {

        hospital = new HospitalSystem();
    }

    // =====================================================
    // TEST 1: REGISTER PATIENT
    // =====================================================

    @Test
    public void testRegisterPatient() {

        Patient patient = new Patient(
                "P001",
                "John",
                "Smith",
                40,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        boolean result =
                hospital.registerPatient(patient);

        assertTrue(result);

        assertEquals(
                1,
                hospital.getTotalRegisteredPatients()
        );
    }

    // =====================================================
    // TEST 2: SEARCH PATIENT
    // =====================================================

    @Test
    public void testSearchPatient() {

        Patient patient = new Patient(
                "P002",
                "Sarah",
                "Jones",
                30,
                "Female",
                "Asthma",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        Patient result =
                hospital.searchPatient("P002");

        assertNotNull(result);

        assertEquals(
                "Sarah",
                result.getFirstName()
        );

        assertEquals(
                "Jones",
                result.getLastName()
        );
    }

    // =====================================================
    // TEST 3: UPDATE PATIENT
    // =====================================================

    @Test
    public void testUpdatePatient() {

        Patient patient = new Patient(
                "P003",
                "Mike",
                "Brown",
                25,
                "Male",
                "Cold",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        boolean result =
                hospital.updatePatient(
                        "P003",
                        "Michael",
                        "Brown",
                        26,
                        "Male",
                        "Pneumonia",
                        PatientCategory.EMERGENCY
                );

        assertTrue(result);

        Patient updated =
                hospital.searchPatient("P003");

        assertEquals(
                "Michael",
                updated.getFirstName()
        );

        assertEquals(
                26,
                updated.getAge()
        );

        assertEquals(
                "Pneumonia",
                updated.getMedicalCondition()
        );

        assertEquals(
                PatientCategory.EMERGENCY,
                updated.getPatientCategory()
        );
    }

    // =====================================================
    // TEST 4: DELETE PATIENT
    // =====================================================

    @Test
    public void testDeletePatient() {

        Patient patient = new Patient(
                "P004",
                "David",
                "Miller",
                50,
                "Male",
                "Diabetes",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(patient);

        boolean result =
                hospital.deletePatient("P004");

        assertTrue(result);

        assertNull(
                hospital.searchPatient("P004")
        );

        assertEquals(
                0,
                hospital.getTotalRegisteredPatients()
        );
    }

    // =====================================================
    // TEST 5: ALLOCATE BED
    // =====================================================

    @Test
    public void testAllocateBed() {

        Inpatient patient =
                new Inpatient(
                        "P005",
                        "James",
                        "Wilson",
                        45,
                        "Male",
                        "Pneumonia",
                        "Ward 1",
                        "Not Allocated"
                );

        hospital.registerPatient(patient);

        boolean result =
                hospital.allocateBed("P005");

        assertTrue(result);

        assertEquals(
                1,
                hospital.getTotalOccupiedBeds()
        );

        assertNotNull(
                hospital.findBedByPatient("P005")
        );

        assertEquals(
                "B01",
                hospital.findBedByPatient("P005")
                        .getBedNumber()
        );
    }

    // =====================================================
    // TEST 6: RELEASE BED
    // =====================================================

    @Test
    public void testReleaseBed() {

        Inpatient patient =
                new Inpatient(
                        "P006",
                        "Peter",
                        "Adams",
                        35,
                        "Male",
                        "Infection",
                        "Ward 1",
                        "Not Allocated"
                );

        hospital.registerPatient(patient);

        hospital.allocateBed("P006");

        boolean result =
                hospital.releaseBed("P006");

        assertTrue(result);

        assertEquals(
                0,
                hospital.getTotalOccupiedBeds()
        );

        assertNull(
                hospital.findBedByPatient("P006")
        );
    }

    // =====================================================
    // TEST 7: PREVENT DUPLICATE PATIENT ID
    // =====================================================

    @Test
    public void testPreventDuplicatePatientId() {

        Patient patient1 =
                new Patient(
                        "P007",
                        "John",
                        "Smith",
                        40,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                );

        Patient patient2 =
                new Patient(
                        "P007",
                        "David",
                        "Jones",
                        35,
                        "Male",
                        "Cold",
                        PatientCategory.OUTPATIENT
                );

        assertTrue(
                hospital.registerPatient(patient1)
        );

        assertFalse(
                hospital.registerPatient(patient2)
        );

        assertEquals(
                1,
                hospital.getTotalRegisteredPatients()
        );
    }

    // =====================================================
    // TEST 8: PREVENT DUPLICATE/OCCUPIED BED
    // =====================================================

    @Test
    public void testPreventDuplicateBedAllocation() {

        Inpatient patient =
                new Inpatient(
                        "P008",
                        "John",
                        "Smith",
                        40,
                        "Male",
                        "Flu",
                        "Ward 1",
                        "Not Allocated"
                );

        hospital.registerPatient(patient);

        assertTrue(
                hospital.allocateBed("P008")
        );

        // Same patient attempts to receive another bed
        assertFalse(
                hospital.allocateBed("P008")
        );

        assertEquals(
                1,
                hospital.getTotalOccupiedBeds()
        );
    }

    // =====================================================
    // TEST 9: PREVENT ALLOCATION WHEN ALL BEDS
    // ARE OCCUPIED
    // =====================================================

    @Test
    public void testPreventAllocationWhenAllBedsOccupied() {

        // Register 21 inpatients
        for (int i = 1; i <= 21; i++) {

            String patientId =
                    String.format("P%03d", i);

            Inpatient patient =
                    new Inpatient(
                            patientId,
                            "Patient",
                            "Test" + i,
                            30,
                            "Male",
                            "Condition",
                            "Ward 1",
                            "Not Allocated"
                    );

            assertTrue(
                    hospital.registerPatient(patient)
            );
        }

        // Allocate all 20 beds
        for (int i = 1; i <= 20; i++) {

            String patientId =
                    String.format("P%03d", i);

            assertTrue(
                    hospital.allocateBed(patientId)
            );
        }

        // 21st patient cannot receive a bed
        assertFalse(
                hospital.allocateBed("P021")
        );

        assertEquals(
                20,
                hospital.getTotalOccupiedBeds()
        );

        assertEquals(
                0,
                hospital.getTotalAvailableBeds()
        );
    }

    // =====================================================
    // TEST 10A: SORT BY SURNAME
    // =====================================================

    @Test
    public void testSortPatientsBySurname() {

        hospital.registerPatient(
                new Patient(
                        "P010",
                        "John",
                        "Zulu",
                        30,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.registerPatient(
                new Patient(
                        "P011",
                        "Sarah",
                        "Adams",
                        25,
                        "Female",
                        "Cold",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.registerPatient(
                new Patient(
                        "P012",
                        "Mike",
                        "Brown",
                        40,
                        "Male",
                        "Infection",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.sortPatientsBySurname();

        assertEquals(
                "Adams",
                hospital.getPatients()
                        .get(0)
                        .getLastName()
        );

        assertEquals(
                "Brown",
                hospital.getPatients()
                        .get(1)
                        .getLastName()
        );

        assertEquals(
                "Zulu",
                hospital.getPatients()
                        .get(2)
                        .getLastName()
        );
    }

    // =====================================================
    // TEST 10B: SORT BY PATIENT ID
    // =====================================================

    @Test
    public void testSortPatientsByPatientId() {

        hospital.registerPatient(
                new Patient(
                        "P003",
                        "John",
                        "Smith",
                        30,
                        "Male",
                        "Flu",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.registerPatient(
                new Patient(
                        "P001",
                        "Sarah",
                        "Jones",
                        25,
                        "Female",
                        "Cold",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.registerPatient(
                new Patient(
                        "P002",
                        "Mike",
                        "Brown",
                        40,
                        "Male",
                        "Infection",
                        PatientCategory.OUTPATIENT
                )
        );

        hospital.sortPatientsByPatientId();

        assertEquals(
                "P001",
                hospital.getPatients()
                        .get(0)
                        .getPatientId()
        );

        assertEquals(
                "P002",
                hospital.getPatients()
                        .get(1)
                        .getPatientId()
        );

        assertEquals(
                "P003",
                hospital.getPatients()
                        .get(2)
                        .getPatientId()
        );
    }
}