/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicalassignment1;

/**
 *
 * @author Student
 */
public class Bed {

    private String bedNumber;
    private boolean occupied;
    private String patientId;

    public Bed(String bedNumber) {

        this.bedNumber = bedNumber;
        this.occupied = false;
        this.patientId = null;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String getPatientId() {
        return patientId;
    }

    public boolean allocateBed(String patientId) {

        if (occupied) {
            return false;
        }

        this.occupied = true;
        this.patientId = patientId;

        return true;
    }

    public void releaseBed() {

        this.occupied = false;
        this.patientId = null;
    }
}
