/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practicalassignment1;

/**
 *
 * @author Student
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class HospitalSystem {

    // Hospital constants
    private static final int TOTAL_BEDS = 20;
    private static final String WARD_NUMBER = "Ward 1";

    // Data storage
    private ArrayList<Patient> patients;
    private Bed[] beds;

    // Scanner
    private Scanner scanner;

    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public HospitalSystem() {

        patients = new ArrayList<>();
        beds = new Bed[TOTAL_BEDS];
        scanner = new Scanner(System.in);

        initializeBeds();
    }

    // =========================================================
    // INITIALISE THE 20 BEDS
    // =========================================================

    private void initializeBeds() {

        for (int i = 0; i < TOTAL_BEDS; i++) {

            String bedNumber = String.format("B%02d", i + 1);

            beds[i] = new Bed(bedNumber);
        }
    }

    // =========================================================
    // MAIN METHOD
    // =========================================================

    public static void main(String[] args) {

        HospitalSystem hospital = new HospitalSystem();

        hospital.runSystem();
    }

    // =========================================================
    // RUN SYSTEM
    // =========================================================

    public void runSystem() {

        int choice;

        do {

            displayMenu();

            choice = readInt("Enter your choice: ");

            switch (choice) {

                case 1:
                    registerPatient();
                    break;

                case 2:
                    searchPatientMenu();
                    break;

                case 3:
                    updatePatientMenu();
                    break;

                case 4:
                    deletePatientMenu();
                    break;

                case 5:
                    displayAllPatients();
                    break;

                case 6:
                    allocateBedMenu();
                    break;

                case 7:
                    releaseBedMenu();
                    break;

                case 8:
                    displayWardLayout();
                    break;

                case 9:
                    displayOccupiedBeds();
                    break;

                case 10:
                    displayAvailableBeds();
                    break;

                case 11:
                    generateWardReport();
                    break;

                case 12:
                    sortPatientsBySurname();
                    displayAllPatients();
                    break;

                case 13:
                    sortPatientsByPatientId();
                    displayAllPatients();
                    break;

                case 14:
                    System.out.println();
                    System.out.println("Thank you for using");
                    System.out.println("Medicare Hospital Patient Admission System.");
                    break;

                default:
                    System.out.println();
                    System.out.println("Invalid choice.");
                    System.out.println("Please select an option from 1 to 14.");
            }

        } while (choice != 14);
    }

    // =========================================================
    // MENU
    // =========================================================

    private void displayMenu() {

        System.out.println();
        System.out.println("==================================================");
        System.out.println("       MEDICARE HOSPITAL PATIENT SYSTEM");
        System.out.println("==================================================");

        System.out.println();
        System.out.println("PATIENT MANAGEMENT");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient");
        System.out.println("3. Update Patient");
        System.out.println("4. Delete Patient");
        System.out.println("5. Display All Registered Patients");

        System.out.println();
        System.out.println("BED MANAGEMENT");
        System.out.println("6. Allocate Bed");
        System.out.println("7. Release Bed");
        System.out.println("8. Display Ward Layout");
        System.out.println("9. Display Occupied Beds");
        System.out.println("10. Display Available Beds");

        System.out.println();
        System.out.println("REPORTS");
        System.out.println("11. Generate Ward Report");

        System.out.println();
        System.out.println("SORTING");
        System.out.println("12. Sort Patients By Surname");
        System.out.println("13. Sort Patients By Patient ID");

        System.out.println();
        System.out.println("14. Exit");

        System.out.println("==================================================");
    }

    // =========================================================
    // FEATURE 1: REGISTER PATIENT
    // =========================================================

    public boolean registerPatient(Patient patient) {

        if (patient == null) {
            return false;
        }

        // Prevent duplicate Patient ID
        if (searchPatient(patient.getPatientId()) != null) {
            return false;
        }

        patients.add(patient);

        return true;
    }

    // =========================================================
    // REGISTER PATIENT MENU
    // =========================================================

    private void registerPatient() {

        System.out.println();
        System.out.println("========== REGISTER PATIENT ==========");

        System.out.print("Enter Patient ID: ");
        String patientId = scanner.nextLine().trim();

        // Check duplicate ID before continuing
        if (searchPatient(patientId) != null) {

            System.out.println();
            System.out.println("ERROR: Patient ID already exists.");

            return;
        }

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine().trim();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine().trim();

        int age = readInt("Enter Age: ");

        System.out.print("Enter Gender: ");
        String gender = scanner.nextLine().trim();

        System.out.print("Enter Medical Condition: ");
        String medicalCondition = scanner.nextLine().trim();

        PatientCategory category = readPatientCategory();

        Patient patient;

        // Create Inpatient object
        if (category == PatientCategory.INPATIENT) {

            patient = new Inpatient(
                    patientId,
                    firstName,
                    lastName,
                    age,
                    gender,
                    medicalCondition,
                    WARD_NUMBER,
                    "Not Allocated"
            );

        }

        // Create normal Patient object for Outpatient
        else if (category == PatientCategory.OUTPATIENT) {

            patient = new Patient(
                    patientId,
                    firstName,
                    lastName,
                    age,
                    gender,
                    medicalCondition,
                    PatientCategory.OUTPATIENT
            );

        }

        // Create normal Patient object for Emergency
        else {

            patient = new Patient(
                    patientId,
                    firstName,
                    lastName,
                    age,
                    gender,
                    medicalCondition,
                    PatientCategory.EMERGENCY
            );
        }

        if (registerPatient(patient)) {

            System.out.println();
            System.out.println("Patient registered successfully.");

        } else {

            System.out.println();
            System.out.println("Patient registration failed.");
        }
    }

    // =========================================================
    // FEATURE 1: SEARCH PATIENT
    // =========================================================

    public Patient searchPatient(String patientId) {

        if (patientId == null || patientId.trim().isEmpty()) {
            return null;
        }

        for (Patient patient : patients) {

            if (patient.getPatientId()
                    .equalsIgnoreCase(patientId.trim())) {

                return patient;
            }
        }

        return null;
    }

    // =========================================================
    // SEARCH PATIENT MENU
    // =========================================================

    private void searchPatientMenu() {

        System.out.println();
        System.out.println("========== SEARCH PATIENT ==========");

        System.out.print("Enter Patient ID: ");

        String patientId = scanner.nextLine();

        Patient patient = searchPatient(patientId);

        if (patient != null) {

            System.out.println();
            System.out.println("Patient found:");

            patient.displayDetails();

        } else {

            System.out.println();
            System.out.println("Patient not found.");
        }
    }

    // =========================================================
    // FEATURE 1: UPDATE PATIENT
    // =========================================================

    public boolean updatePatient(
            String patientId,
            String firstName,
            String lastName,
            int age,
            String gender,
            String medicalCondition,
            PatientCategory category) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // If an inpatient changes category,
        // release their bed.
        if (patient.getPatientCategory() == PatientCategory.INPATIENT
                && category != PatientCategory.INPATIENT) {

            releaseBed(patientId);
        }

        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setMedicalCondition(medicalCondition);
        patient.setPatientCategory(category);

        return true;
    }

    // =========================================================
    // UPDATE PATIENT MENU
    // =========================================================

    private void updatePatientMenu() {

        System.out.println();
        System.out.println("========== UPDATE PATIENT ==========");

        System.out.print("Enter Patient ID: ");

        String patientId = scanner.nextLine();

        Patient existingPatient = searchPatient(patientId);

        if (existingPatient == null) {

            System.out.println();
            System.out.println("Patient not found.");

            return;
        }

        System.out.print("Enter New First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter New Last Name: ");
        String lastName = scanner.nextLine();

        int age = readInt("Enter New Age: ");

        System.out.print("Enter New Gender: ");
        String gender = scanner.nextLine();

        System.out.print("Enter New Medical Condition: ");
        String medicalCondition = scanner.nextLine();

        PatientCategory category = readPatientCategory();

        boolean updated = updatePatient(
                patientId,
                firstName,
                lastName,
                age,
                gender,
                medicalCondition,
                category
        );

        if (updated) {

            System.out.println();
            System.out.println("Patient details updated successfully.");

        } else {

            System.out.println();
            System.out.println("Patient update failed.");
        }
    }

    // =========================================================
    // FEATURE 1: DELETE PATIENT
    // =========================================================

    public boolean deletePatient(String patientId) {

        Patient patient = searchPatient(patientId);

        if (patient == null) {
            return false;
        }

        // Patient must release bed before deletion
        if (findBedByPatient(patientId) != null) {
            return false;
        }

        patients.remove(patient);

        return true;
    }

    // =========================================================
    // DELETE PATIENT MENU
    // =========================================================

    private void deletePatientMenu() {

        System.out.println();
        System.out.println("========== DELETE PATIENT ==========");

        System.out.print("Enter Patient ID: ");

        String patientId = scanner.nextLine();

        if (deletePatient(patientId)) {

            System.out.println();
            System.out.println("Patient deleted successfully.");

        } else {

            System.out.println();
            System.out.println("Patient could not be deleted.");

            if (searchPatient(patientId) == null) {

                System.out.println("Reason: Patient does not exist.");

            } else if (findBedByPatient(patientId) != null) {

                System.out.println(
                        "Reason: Patient still has a bed allocated."
                );
            }
        }
    }

    // =========================================================
    // FEATURE 1: DISPLAY ALL PATIENTS
    // =========================================================

    public void displayAllPatients() {

        System.out.println();
        System.out.println("========== ALL REGISTERED PATIENTS ==========");

        if (patients.isEmpty()) {

            System.out.println("No patients are currently registered.");

            return;
        }

        for (Patient patient : patients) {

            patient.displayDetails();
        }
    }

    // =========================================================
    // FEATURE 2: FIND AVAILABLE BED
    // =========================================================

    public Bed findAvailableBed() {

        for (Bed bed : beds) {

            if (!bed.isOccupied()) {

                return bed;
            }
        }

        return null;
    }

    // =========================================================
    // FEATURE 2: FIND BED BY PATIENT
    // =========================================================

    public Bed findBedByPatient(String patientId) {

        if (patientId == null) {
            return null;
        }

        for (Bed bed : beds) {

            if (bed.isOccupied()
                    && bed.getPatientId()
                    .equalsIgnoreCase(patientId)) {

                return bed;
            }
        }

        return null;
    }

    // =========================================================
    // FEATURE 2: ALLOCATE BED
    // =========================================================

    public boolean allocateBed(String patientId) {

        Patient patient = searchPatient(patientId);

        // Patient must exist
        if (patient == null) {
            return false;
        }

        // Only inpatients may receive beds
        if (patient.getPatientCategory()
                != PatientCategory.INPATIENT) {

            return false;
        }

        // Patient can only occupy one bed
        if (findBedByPatient(patientId) != null) {

            return false;
        }

        // Find an available bed
        Bed availableBed = findAvailableBed();

        // All beds occupied
        if (availableBed == null) {

            return false;
        }

        // Allocate bed
        boolean allocated =
                availableBed.allocateBed(patientId);

        if (!allocated) {
            return false;
        }

        // Update Inpatient's bed information
        if (patient instanceof Inpatient) {

            Inpatient inpatient =
                    (Inpatient) patient;

            inpatient.setWardNumber(WARD_NUMBER);

            inpatient.setBedNumber(
                    availableBed.getBedNumber()
            );
        }

        return true;
    }

    // =========================================================
    // ALLOCATE BED MENU
    // =========================================================

    private void allocateBedMenu() {

        System.out.println();
        System.out.println("========== ALLOCATE BED ==========");

        System.out.print("Enter Patient ID: ");

        String patientId = scanner.nextLine();

        Patient patient = searchPatient(patientId);

        if (patient == null) {

            System.out.println(
                    "Patient does not exist."
            );

            return;
        }

        if (patient.getPatientCategory()
                != PatientCategory.INPATIENT) {

            System.out.println(
                    "Only inpatients may be allocated a hospital bed."
            );

            return;
        }

        if (findBedByPatient(patientId) != null) {

            System.out.println(
                    "This patient already has a bed."
            );

            return;
        }

        if (findAvailableBed() == null) {

            System.out.println(
                    "No beds are currently available."
            );

            return;
        }

        if (allocateBed(patientId)) {

            Bed bed = findBedByPatient(patientId);

            System.out.println();
            System.out.println(
                    "Bed allocated successfully."
            );

            System.out.println(
                    "Patient: "
                    + patient.getFirstName()
                    + " "
                    + patient.getLastName()
            );

            System.out.println(
                    "Bed: "
                    + bed.getBedNumber()
            );
        }
    }

    // =========================================================
    // FEATURE 2: RELEASE BED
    // =========================================================

    public boolean releaseBed(String patientId) {

        Bed bed = findBedByPatient(patientId);

        if (bed == null) {
            return false;
        }

        bed.releaseBed();

        Patient patient = searchPatient(patientId);

        if (patient instanceof Inpatient) {

            Inpatient inpatient =
                    (Inpatient) patient;

            inpatient.setBedNumber("Not Allocated");
        }

        return true;
    }

    // =========================================================
    // RELEASE BED MENU
    // =========================================================

    private void releaseBedMenu() {

        System.out.println();
        System.out.println("========== RELEASE BED ==========");

        System.out.print("Enter Patient ID: ");

        String patientId = scanner.nextLine();

        if (releaseBed(patientId)) {

            System.out.println();
            System.out.println(
                    "Bed released successfully."
            );

        } else {

            System.out.println();
            System.out.println(
                    "No bed is allocated to this patient."
            );
        }
    }

    // =========================================================
    // FEATURE 2: DISPLAY WARD LAYOUT
    // =========================================================

    public void displayWardLayout() {

        System.out.println();
        System.out.println("==================================================");
        System.out.println("                MEDICARE WARD");
        System.out.println("                 4 x 5 LAYOUT");
        System.out.println("==================================================");

        for (int i = 0; i < TOTAL_BEDS; i++) {

            Bed bed = beds[i];

            if (bed.isOccupied()) {

                System.out.printf(
                        "%-25s",
                        bed.getBedNumber()
                        + " - Occupied ("
                        + bed.getPatientId()
                        + ")"
                );

            } else {

                System.out.printf(
                        "%-25s",
                        bed.getBedNumber()
                        + " - Available"
                );
            }

            if ((i + 1) % 5 == 0) {

                System.out.println();
            }
        }

        System.out.println("==================================================");
    }

    // =========================================================
    // FEATURE 2: DISPLAY OCCUPIED BEDS
    // =========================================================

    public void displayOccupiedBeds() {

        System.out.println();
        System.out.println("========== OCCUPIED BEDS ==========");

        boolean found = false;

        for (Bed bed : beds) {

            if (bed.isOccupied()) {

                Patient patient =
                        searchPatient(
                                bed.getPatientId()
                        );

                System.out.println(
                        bed.getBedNumber()
                        + " -> "
                        + patient.getFirstName()
                        + " "
                        + patient.getLastName()
                        + " ("
                        + patient.getPatientId()
                        + ")"
                );

                found = true;
            }
        }

        if (!found) {

            System.out.println(
                    "There are no occupied beds."
            );
        }
    }

    // =========================================================
    // FEATURE 3: DISPLAY AVAILABLE BEDS
    // =========================================================

    public void displayAvailableBeds() {

        System.out.println();
        System.out.println("========== AVAILABLE BEDS ==========");

        boolean found = false;

        for (Bed bed : beds) {

            if (!bed.isOccupied()) {

                System.out.println(
                        bed.getBedNumber()
                        + " -> Available"
                );

                found = true;
            }
        }

        if (!found) {

            System.out.println(
                    "There are no available beds."
            );
        }
    }

    // =========================================================
    // FEATURE 3: TOTAL REGISTERED PATIENTS
    // =========================================================

    public int getTotalRegisteredPatients() {

        return patients.size();
    }

    // =========================================================
    // FEATURE 3: TOTAL OCCUPIED BEDS
    // =========================================================

    public int getTotalOccupiedBeds() {

        int occupiedBeds = 0;

        for (Bed bed : beds) {

            if (bed.isOccupied()) {

                occupiedBeds++;
            }
        }

        return occupiedBeds;
    }

    // =========================================================
    // FEATURE 3: TOTAL AVAILABLE BEDS
    // =========================================================

    public int getTotalAvailableBeds() {

        return TOTAL_BEDS
                - getTotalOccupiedBeds();
    }

    // =========================================================
    // FEATURE 3: OCCUPANCY PERCENTAGE
    // =========================================================

    public double getWardOccupancyPercentage() {

        return (getTotalOccupiedBeds()
                * 100.0)
                / TOTAL_BEDS;
    }

    // =========================================================
    // FEATURE 3: WARD REPORT
    // =========================================================

    public void generateWardReport() {

        System.out.println();
        System.out.println("==================================================");
        System.out.println("              MEDICARE WARD REPORT");
        System.out.println("==================================================");

        System.out.println(
                "Total Registered Patients: "
                + getTotalRegisteredPatients()
        );

        System.out.println(
                "Total Available Beds: "
                + getTotalAvailableBeds()
        );

        System.out.println(
                "Total Occupied Beds: "
                + getTotalOccupiedBeds()
        );

        System.out.printf(
                "Ward Occupancy Percentage: %.2f%%%n",
                getWardOccupancyPercentage()
        );

        System.out.println("==================================================");
    }

    // =========================================================
    // FEATURE 5: SORT BY SURNAME
    // =========================================================

    public void sortPatientsBySurname() {

        patients.sort(
                Comparator.comparing(
                        Patient::getLastName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        System.out.println();
        System.out.println(
                "Patients sorted by surname."
        );
    }

    // =========================================================
    // FEATURE 5: SORT BY PATIENT ID
    // =========================================================

    public void sortPatientsByPatientId() {

        patients.sort(
                Comparator.comparing(
                        Patient::getPatientId,
                        String.CASE_INSENSITIVE_ORDER
                )
        );

        System.out.println();
        System.out.println(
                "Patients sorted by Patient ID."
        );
    }

    // =========================================================
    // GET PATIENT LIST
    // Used for JUnit testing
    // =========================================================

    public ArrayList<Patient> getPatients() {

        return patients;
    }

    // =========================================================
    // GET BEDS
    // Used for testing
    // =========================================================

    public Bed[] getBeds() {

        return beds;
    }

    // =========================================================
    // READ INTEGER
    // =========================================================

    private int readInt(String message) {

        while (true) {

            System.out.print(message);

            try {

                int value =
                        Integer.parseInt(
                                scanner.nextLine()
                        );

                if (value < 0) {

                    System.out.println(
                            "Please enter a positive number."
                    );

                    continue;
                }

                return value;

            } catch (NumberFormatException e) {

                System.out.println(
                        "Invalid input. Please enter a number."
                );
            }
        }
    }

    // =========================================================
    // READ PATIENT CATEGORY
    // =========================================================

    private PatientCategory readPatientCategory() {

        while (true) {

            System.out.println();
            System.out.println("Patient Category");
            System.out.println("----------------");
            System.out.println("1. Inpatient");
            System.out.println("2. Outpatient");
            System.out.println("3. Emergency");

            int choice =
                    readInt(
                            "Select patient category: "
                    );

            switch (choice) {

                case 1:
                    return PatientCategory.INPATIENT;

                case 2:
                    return PatientCategory.OUTPATIENT;

                case 3:
                    return PatientCategory.EMERGENCY;

                default:

                    System.out.println();
                    System.out.println(
                            "Invalid category."
                    );
            }
        }
    }
}